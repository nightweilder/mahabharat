// layout.js - places every person on a horizontal family tree.
// Columns = generations (left to right). Rows = vertical slots.
// A "unit" is one person plus their spouses stacked below them in the same column.
// Children of a unit go in the next column, centred next to their parents.

function computeLayout(persons) {
  var byId = {}, units = {}, roots = [], pos = {}, links = [];
  persons.forEach(function (p) { byId[p.id] = p; });

  function leadOf(id) { return byId[id].so ? byId[id].so : id; }

  persons.forEach(function (p) {
    if (!p.so) units[p.id] = { id: p.id, members: [p.id], kids: [], col: 0, h: 0 };
  });
  persons.forEach(function (p) {
    if (p.so) units[p.so].members.push(p.id);
  });
  persons.forEach(function (p) {
    if (p.so) return;
    if (p.lp) units[leadOf(p.lp)].kids.push(units[p.id]);
    else roots.push(units[p.id]);
  });

  function height(u) {
    var sum = 0;
    u.kids.forEach(function (k) { sum += height(k); });
    u.h = Math.max(u.members.length, sum);
    u.kidsH = sum;
    return u.h;
  }

  var maxCol = 0, maxRow = 0;
  function place(u, col, top) {
    var m = u.members.length;
    var y = top + (u.h - m) / 2;
    u.members.forEach(function (id, i) {
      pos[id] = { col: col, row: y + i };
      if (i > 0) links.push([u.members[i - 1], id]);
    });
    if (col > maxCol) maxCol = col;
    if (y + m - 1 > maxRow) maxRow = y + m - 1;
    var kt = top + (u.h - u.kidsH) / 2;
    u.kids.forEach(function (k) { place(k, col + 1, kt); kt += k.h; });
  }

  var top = 0;
  roots.forEach(function (r) {
    height(r);
    place(r, byId[r.id].g || 0, top);
    top += r.h;
  });

  return { pos: pos, links: links, cols: maxCol + 1, rows: maxRow + 1 };
}

if (typeof module !== 'undefined') module.exports = computeLayout;
