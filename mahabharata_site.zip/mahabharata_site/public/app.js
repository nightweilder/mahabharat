// app.js - the front end. It asks the backend (server.js) for data, builds the
// 3D portraits with three.js, draws the family tree and fills every tab.
(function () {
  'use strict';

  var HOUSE = {
    kuru: ['Kuru dynasty', '#e8c36a'],
    pandava: ['Pandavas and kin', '#4aa8ff'],
    kaurava: ['Kauravas and allies', '#ff5a5f'],
    yadava: ['Yadavas', '#2ec4a6'],
    panchala: ['Panchalas', '#ff9142'],
    guru: ['Sages and teachers', '#b79cff'],
    gandhara: ['Gandhara', '#9aa7bd']
  };
  var SKIN = [0, '#f2cfa8', '#e3b184', '#c68e63', '#9b6b47', '#5e86d6'];
  var GEN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII'];
  var NW = 150, NH = 212, COLW = 250, ROWH = 236, PADX = 40, TOPY = 64;
  var BLANK = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';

  var D = {}, byId = {}, layout = null, scale = 0.62, glOK = true;
  var edges = [], nodes = {};

  function $(s, r) { return (r || document).querySelector(s); }
  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function api(p) { return fetch(p).then(function (r) { if (!r.ok) throw new Error(p + ' failed'); return r.json(); }); }

  /* ================= 3D: figures built from basic shapes ================= */
  var RW = 360, RH = 440, rr, rs, rc, rim;

  function mat(c, o) {
    return new THREE.MeshStandardMaterial(Object.assign({ color: c, roughness: 0.5, metalness: 0.05 }, o || {}));
  }
  function mesh(g, m, x, y, z) { var o = new THREE.Mesh(g, m); o.position.set(x || 0, y || 0, z || 0); return o; }
  function cyl(rt, rb, h, m, x, y, z) { return mesh(new THREE.CylinderGeometry(rt, rb, h, 28), m, x, y, z); }
  function ball(r, m, x, y, z) { return mesh(new THREE.SphereGeometry(r, 28, 18), m, x, y, z); }
  function cone(r, h, m, x, y, z) { return mesh(new THREE.ConeGeometry(r, h, 20), m, x, y, z); }
  function ring(r, t, m, x, y, z) { return mesh(new THREE.TorusGeometry(r, t, 12, 48), m, x, y, z); }

  function lights(scene) {
    scene.add(new THREE.AmbientLight(0xffffff, 0.62));
    var key = new THREE.DirectionalLight(0xffffff, 1.0); key.position.set(2, 3, 4); scene.add(key);
    var r = new THREE.DirectionalLight(0xffffff, 0.8); r.position.set(-3, 1.5, -2); scene.add(r);
    return r;
  }
  function makeCamera(aspect) {
    var c = new THREE.PerspectiveCamera(32, aspect, 0.1, 50);
    c.position.set(0, 0.45, 6.6); c.lookAt(0, 0.2, 0);
    return c;
  }

  function buildProp(kind, col) {
    var g = new THREE.Group();
    var m = mat(col, { metalness: 0.6, roughness: 0.3 });
    var steel = mat('#c9d0e0', { metalness: 0.8, roughness: 0.25 });
    var i, a;
    if (kind === 'bow') {
      var arc = new THREE.Mesh(new THREE.TorusGeometry(0.75, 0.04, 10, 40, Math.PI), m);
      arc.rotation.z = Math.PI / 2; g.add(arc);
      g.add(cyl(0.012, 0.012, 1.5, mat('#f3eeff'), 0, 0, 0));
    } else if (kind === 'mace') {
      g.add(cyl(0.05, 0.05, 1.5, mat('#7a5a3a'), 0, 0, 0));
      g.add(ball(0.25, m, 0, 0.85, 0));
      for (i = 0; i < 8; i++) {
        a = i * Math.PI / 4;
        var sp = cone(0.06, 0.18, steel, Math.cos(a) * 0.27, 0.85, Math.sin(a) * 0.27);
        sp.rotation.z = -Math.cos(a) * Math.PI / 2; sp.rotation.x = Math.sin(a) * Math.PI / 2;
        g.add(sp);
      }
      g.add(cone(0.06, 0.2, steel, 0, 1.2, 0));
    } else if (kind === 'spear') {
      g.add(cyl(0.035, 0.035, 2.4, mat('#7a5a3a'), 0, 0, 0));
      g.add(cone(0.1, 0.45, m, 0, 1.4, 0));
    } else if (kind === 'sword') {
      g.add(mesh(new THREE.BoxGeometry(0.13, 1.2, 0.03), steel, 0, 0.75, 0));
      g.add(mesh(new THREE.BoxGeometry(0.5, 0.08, 0.08), m, 0, 0.12, 0));
      g.add(cyl(0.04, 0.04, 0.4, mat('#4a2f1d'), 0, -0.12, 0));
      g.add(ball(0.07, m, 0, -0.35, 0));
    } else if (kind === 'staff') {
      g.add(cyl(0.045, 0.045, 2.2, mat('#7a5a3a'), 0, 0, 0));
      g.add(ball(0.1, m, 0, 1.15, 0));
    } else if (kind === 'chakra') {
      g.add(ring(0.5, 0.05, m, 0, 0, 0));
      g.add(ring(0.3, 0.03, m, 0, 0, 0));
      for (i = 0; i < 8; i++) {
        a = i * Math.PI / 4;
        var t = cone(0.06, 0.2, m, Math.cos(a) * 0.55, Math.sin(a) * 0.55, 0);
        t.rotation.z = a - Math.PI / 2; g.add(t);
      }
      g.userData.spin = true;
    } else if (kind === 'flute') {
      var f = cyl(0.035, 0.035, 1.0, mat('#7a5a3a'), 0, 0, 0); g.add(f);
      for (i = 0; i < 4; i++) g.add(ball(0.025, mat('#2a1a10'), 0, -0.2 + i * 0.13, 0.035));
    } else if (kind === 'plow') {
      g.add(cyl(0.05, 0.05, 1.8, mat('#7a5a3a'), 0, 0, 0));
      var h = mesh(new THREE.BoxGeometry(0.8, 0.12, 0.12), m, 0.3, 0.9, 0); g.add(h);
    } else if (kind === 'scroll') {
      g.add(cyl(0.1, 0.1, 0.7, mat('#efe2bd'), 0, 0, 0));
      g.add(cyl(0.12, 0.12, 0.05, m, 0, 0.36, 0)); g.add(cyl(0.12, 0.12, 0.05, m, 0, -0.36, 0));
    } else if (kind === 'conch') {
      var s = ball(0.32, mat(col, { roughness: 0.3 }), 0, 0, 0); s.scale.set(1, 0.8, 0.8); g.add(s);
      var c2 = cone(0.2, 0.6, mat(col, { roughness: 0.3 }), 0.4, 0, 0); c2.rotation.z = -Math.PI / 2; g.add(c2);
      g.add(ring(0.28, 0.025, m, 0, 0, 0.05));
    } else if (kind === 'astra') {
      g.add(ball(0.42, mat(col, { emissive: col, emissiveIntensity: 0.55, roughness: 0.25 }), 0, 0, 0));
      var r1 = ring(0.7, 0.03, mat(col, { emissive: col, emissiveIntensity: 0.5 }), 0, 0, 0); r1.rotation.x = 1.2; g.add(r1);
      var r2 = ring(0.6, 0.03, mat(col, { emissive: col, emissiveIntensity: 0.5 }), 0, 0, 0); r2.rotation.y = 1.2; g.add(r2);
      g.userData.spin = true;
    }
    return g;
  }

  function buildFigure(c) {
    var L = c.l, G = new THREE.Group();
    var col = HOUSE[c.h][1];
    var sk = mat(SKIN[L.s] || SKIN[2], { roughness: 0.7 });
    var cl = mat(L.c, { roughness: 0.6 });
    var ac = mat(L.a, { metalness: 0.75, roughness: 0.28 });
    var hr = mat(L.hr, { roughness: 0.85 });
    var fem = L.f === 1;

    // glow behind the figure
    G.add(mesh(new THREE.CircleGeometry(1.55, 64), new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.22 }), 0, 0.3, -1));
    G.add(ring(1.5, 0.035, new THREE.MeshBasicMaterial({ color: col }), 0, 0.3, -1));

    // body
    var tw = fem ? 0.52 : 0.6, bw = fem ? 0.82 : 0.92;
    G.add(cyl(tw, bw, 1.3, cl, 0, -0.65, 0));
    var sh = ball(0.85, cl, 0, -0.05, 0); sh.scale.set(fem ? 1.0 : 1.12, 0.4, 0.62); G.add(sh);
    var nk = ring(0.4, 0.05, ac, 0, 0.0, 0.1); nk.rotation.x = Math.PI / 2.3; G.add(nk);
    G.add(ball(0.07, ac, 0, -0.3, 0.52));
    G.add(cyl(0.17, 0.2, 0.3, sk, 0, 0.12, 0));
    var armL = cyl(0.16, 0.12, 1.0, cl, -0.98, -0.55, 0.02); armL.rotation.z = 0.1; G.add(armL);
    var armR = cyl(0.16, 0.12, 1.0, cl, 0.98, -0.55, 0.02); armR.rotation.z = -0.1; G.add(armR);
    G.add(ball(0.13, sk, -1.06, -1.1, 0.05));
    G.add(ball(0.13, sk, 1.06, -1.1, 0.05));

    // head and face
    var head = ball(0.5, sk, 0, 0.68, 0); head.scale.set(0.9, 1.08, 0.95); G.add(head);
    G.add(ball(0.05, mat('#1a1420'), -0.17, 0.72, 0.44));
    G.add(ball(0.05, mat('#1a1420'), 0.17, 0.72, 0.44));
    G.add(ball(0.05, sk, 0, 0.62, 0.47));
    G.add(mesh(new THREE.BoxGeometry(0.12, 0.022, 0.03), mat('#8a3a3a'), 0, 0.5, 0.45));
    if (!L.bl && c.id !== 'krishna' || c.id === 'krishna') G.add(mesh(new THREE.BoxGeometry(0.035, 0.07, 0.03), mat(c.id === 'krishna' ? '#ffffff' : '#d02a2a'), 0, 0.89, 0.435));
    if (fem || L.a) {
      G.add(ball(0.05, ac, -0.46, 0.55, 0.05));
      G.add(ball(0.05, ac, 0.46, 0.55, 0.05));
    }

    // hair
    var hd = L.hd;
    if (hd !== 'jata' && hd !== 'turban' && hd !== 'helmet') {
      var cap = new THREE.Mesh(new THREE.SphereGeometry(0.52, 32, 20, 0, Math.PI * 2, 0, Math.PI * 0.34), hr);
      cap.scale.set(0.97, 1.1, 1.0); cap.position.set(0, 0.68, -0.04); G.add(cap);
    }
    if (fem) { var back = ball(0.5, hr, 0, 0.35, -0.28); back.scale.set(0.95, 1.35, 0.7); G.add(back); }
    if (L.bd) { var bd = ball(0.3, hr, 0, 0.4, 0.3); bd.scale.set(1, 0.95, 0.7); G.add(bd); }

    // headgear
    var top, i, a;
    if (hd === 'crown') {
      G.add(cyl(0.5, 0.44, 0.24, ac, 0, 1.0, 0));
      for (i = 0; i < 5; i++) {
        a = i * Math.PI * 2 / 5;
        G.add(cone(0.07, 0.28, ac, Math.cos(a) * 0.42, 1.26, Math.sin(a) * 0.42));
      }
      G.add(cone(0.1, 0.42, ac, 0, 1.36, 0));
      G.add(ball(0.06, mat('#ff3a5a', { emissive: '#ff3a5a', emissiveIntensity: 0.6 }), 0, 1.02, 0.5));
      if (c.id === 'krishna') {
        var fe = ball(0.1, mat('#2fd0a0', { emissive: '#139a76', emissiveIntensity: 0.5 }), 0.15, 1.5, 0); fe.scale.set(0.7, 2.2, 0.3); fe.rotation.z = -0.4; G.add(fe);
        G.add(ball(0.04, mat('#2a4aff'), 0.13, 1.6, 0.03));
      }
    } else if (hd === 'jata') {
      var bun = ball(0.27, hr, 0, 1.2, -0.04); bun.scale.set(1, 1, 0.9); G.add(bun);
      var jt = new THREE.Mesh(new THREE.SphereGeometry(0.52, 32, 20, 0, Math.PI * 2, 0, Math.PI * 0.34), hr);
      jt.scale.set(0.97, 1.1, 1.0); jt.position.set(0, 0.68, -0.04); G.add(jt);
      var bnd = ring(0.43, 0.035, ac, 0, 0.98, 0); bnd.rotation.x = Math.PI / 2; G.add(bnd);
    } else if (hd === 'turban') {
      var tb = ball(0.56, cl, 0, 0.98, 0); tb.scale.set(1.0, 0.72, 1.0); G.add(tb);
      var tr = ring(0.5, 0.06, ac, 0, 0.9, 0); tr.rotation.x = Math.PI / 2; G.add(tr);
      G.add(ball(0.06, mat('#ff3a5a'), 0, 0.92, 0.52));
    } else if (hd === 'helmet') {
      var hm = new THREE.Mesh(new THREE.SphereGeometry(0.55, 32, 20, 0, Math.PI * 2, 0, Math.PI * 0.5), mat('#b8bfd2', { metalness: 0.85, roughness: 0.25 }));
      hm.scale.set(1, 1.05, 1.05); hm.position.set(0, 0.82, 0); G.add(hm);
      var hr2 = ring(0.54, 0.04, ac, 0, 0.82, 0); hr2.rotation.x = Math.PI / 2; G.add(hr2);
      G.add(cone(0.07, 0.34, ac, 0, 1.5, 0));
    } else if (hd === 'veil') {
      var vl = new THREE.Mesh(new THREE.SphereGeometry(0.58, 32, 20, 0, Math.PI * 2, 0, Math.PI * 0.42), cl);
      vl.scale.set(1, 1.1, 1.0); vl.position.set(0, 0.64, -0.05); G.add(vl);
      var vb = ball(0.6, cl, 0, 0.3, -0.34); vb.scale.set(1.0, 1.25, 0.55); G.add(vb);
    }
    if (L.bl) {
      var bf = ring(0.465, 0.075, mat('#f2f2f2'), 0, 0.72, 0); bf.rotation.x = Math.PI / 2; bf.scale.set(0.95, 1, 1.0); G.add(bf);
    }

    // held item
    if (L.pr && L.pr !== 'none') {
      var p = buildProp(L.pr, L.a);
      if (L.pr === 'bow') { p.scale.setScalar(0.85); p.position.set(-0.85, 0.05, 0.25); }
      else if (L.pr === 'chakra') { p.scale.setScalar(0.8); p.position.set(1.05, 0.2, 0.5); }
      else if (L.pr === 'flute') { p.position.set(0.6, -0.15, 0.62); p.rotation.z = -0.9; }
      else if (L.pr === 'conch') { p.position.set(1.0, -0.1, 0.5); }
      else if (L.pr === 'spear' || L.pr === 'staff') { p.position.set(1.12, 0.2, 0.3); p.rotation.z = -0.1; }
      else { p.position.set(1.12, -0.2, 0.3); p.rotation.z = -0.12; }
      G.add(p);
    }
    return G;
  }

  function dispose(o) {
    o.traverse(function (n) {
      if (n.geometry) n.geometry.dispose();
      if (n.material) n.material.dispose();
    });
  }

  function initRender() {
    try {
      rr = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
      rr.setPixelRatio(1); rr.setSize(RW, RH);
      rs = new THREE.Scene(); rc = makeCamera(RW / RH); rim = lights(rs);
    } catch (e) { glOK = false; }
  }
  function snap(group, color) {
    rim.color.set(color);
    rs.add(group); rr.render(rs, rc);
    var u = rr.domElement.toDataURL('image/png');
    rs.remove(group); dispose(group);
    return u;
  }
  function fallbackPortrait(c) {
    var cv = document.createElement('canvas'); cv.width = 180; cv.height = 220;
    var x = cv.getContext('2d'), col = HOUSE[c.h][1];
    x.fillStyle = col; x.globalAlpha = 0.3; x.beginPath(); x.arc(90, 100, 80, 0, 7); x.fill(); x.globalAlpha = 1;
    x.fillStyle = SKIN[c.l.s] || SKIN[2]; x.beginPath(); x.arc(90, 90, 38, 0, 7); x.fill();
    x.fillStyle = c.l.c; x.beginPath(); x.ellipse(90, 190, 62, 50, 0, 3.14, 6.28); x.fill();
    return cv.toDataURL();
  }
  function portraitFor(c) { return glOK ? snap(buildFigure(c), HOUSE[c.h][1]) : fallbackPortrait(c); }
  function weaponImage(w) {
    if (!glOK) return BLANK;
    var g = new THREE.Group(); g.add(buildProp(w.m, w.c));
    if (w.m === 'bow') { g.scale.setScalar(1.7); g.rotation.z = -0.35; g.position.x = 0.6; }
    if (w.m === 'mace') { g.scale.setScalar(1.45); g.rotation.z = 0.7; }
    if (w.m === 'sword') { g.scale.setScalar(1.7); g.rotation.z = 0.7; }
    if (w.m === 'spear') { g.scale.setScalar(1.15); g.rotation.z = 0.75; }
    if (w.m === 'conch') { g.scale.setScalar(2.8); g.rotation.z = 0.3; }
    if (w.m === 'chakra') { g.scale.setScalar(2.5); g.rotation.y = -0.5; }
    if (w.m === 'astra') g.scale.setScalar(2.1);
    return snap(g, w.c);
  }

  /* ================= family tree ================= */
  function buildTree() {
    layout = computeLayout(D.chars);
    var inner = $('#treeInner');
    var W = PADX * 2 + (layout.cols - 1) * COLW + NW;
    var H = TOPY + 40 + layout.rows * ROWH;
    inner.style.width = W + 'px'; inner.style.height = H + 'px';
    inner.dataset.w = W; inner.dataset.h = H;

    var NS = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('width', W); svg.setAttribute('height', H);
    inner.appendChild(svg);

    for (var g = 0; g < layout.cols; g++) {
      var gl = el('div', 'gen', 'Generation ' + GEN[g]);
      gl.style.left = (PADX + g * COLW) + 'px'; inner.appendChild(gl);
    }

    function px(id) { var p = layout.pos[id]; return { x: PADX + p.col * COLW, y: TOPY + p.row * ROWH }; }

    D.chars.forEach(function (c) {
      var p = px(c.id), hc = HOUSE[c.h][1];
      var n = el('div', 'node');
      n.style.left = p.x + 'px'; n.style.top = p.y + 'px'; n.style.setProperty('--hc', hc);
      n.innerHTML = '<img class="portrait" data-p="' + c.id + '" src="' + BLANK + '" alt="' + esc(c.n) + '" draggable="false">' +
        '<div class="nm">' + esc(c.n) + '</div><div class="rl">' + esc(c.r) + '</div>';
      n.dataset.id = c.id;
      n.onclick = function () { if (!panMoved) showChar(c.id); };
      n.onmouseenter = function () { trace(c.id); };
      n.onmouseleave = function () { trace(null); };
      inner.appendChild(n); nodes[c.id] = n;
    });

    function curve(a, b, col) {
      var x1 = a.x + NW, y1 = a.y + 90, x2 = b.x, y2 = b.y + 90, xm = (x1 + x2) / 2;
      var path = document.createElementNS(NS, 'path');
      path.setAttribute('d', 'M' + x1 + ' ' + y1 + ' C' + xm + ' ' + y1 + ',' + xm + ' ' + y2 + ',' + x2 + ' ' + y2);
      path.setAttribute('class', 'edge'); path.setAttribute('stroke', col); path.style.color = col;
      svg.appendChild(path);
      return path;
    }
    D.chars.forEach(function (c) {
      (c.p || []).forEach(function (pid) {
        if (!byId[pid]) return;
        var path = curve(px(pid), px(c.id), HOUSE[byId[pid].h][1]);
        edges.push({ el: path, from: pid, to: c.id });
      });
    });
    layout.links.forEach(function (l) {
      var a = px(l[0]), b = px(l[1]), x = a.x + NW / 2;
      var line = document.createElementNS(NS, 'path');
      line.setAttribute('d', 'M' + x + ' ' + (a.y + NH) + ' L' + x + ' ' + b.y);
      line.setAttribute('class', 'edge sp'); line.setAttribute('stroke', '#e8c36a');
      svg.appendChild(line); edges.push({ el: line, from: l[0], to: l[1] });
    });

    var lg = $('#legend');
    Object.keys(HOUSE).forEach(function (k) {
      lg.appendChild(el('span', 'chip', '<i style="background:' + HOUSE[k][1] + '"></i>' + HOUSE[k][0]));
    });
    setScale(0.62);
  }

  function trace(id) {
    var near = {};
    edges.forEach(function (e) {
      var on = id && (e.from === id || e.to === id);
      e.el.classList.toggle('hl', !!on);
      e.el.classList.toggle('dim', !!id && !on);
      if (on) { near[e.from] = 1; near[e.to] = 1; }
    });
    Object.keys(nodes).forEach(function (k) { nodes[k].classList.toggle('dim', !!id && !near[k]); });
  }

  function setScale(s) {
    scale = Math.max(0.25, Math.min(1.2, s));
    var inner = $('#treeInner'), sizer = $('#treeSizer');
    inner.style.transform = 'scale(' + scale + ')';
    sizer.style.width = (inner.dataset.w * scale) + 'px'; sizer.style.height = (inner.dataset.h * scale) + 'px';
    $('#zval').textContent = Math.round(scale * 100) + '%';
  }

  var panMoved = false;
  function setupPan() {
    var sc = $('#treeScroll'), down = false, sx, sy, sl, st;
    sc.addEventListener('pointerdown', function (e) { down = true; panMoved = false; sx = e.clientX; sy = e.clientY; sl = sc.scrollLeft; st = sc.scrollTop; });
    window.addEventListener('pointermove', function (e) {
      if (!down) return;
      var dx = e.clientX - sx, dy = e.clientY - sy;
      if (Math.abs(dx) + Math.abs(dy) > 6) { panMoved = true; sc.classList.add('drag'); }
      if (panMoved) { sc.scrollLeft = sl - dx; sc.scrollTop = st - dy; }
    });
    window.addEventListener('pointerup', function () { down = false; sc.classList.remove('drag'); setTimeout(function () { panMoved = false; }, 0); });
    sc.addEventListener('wheel', function (e) { if (e.ctrlKey) { e.preventDefault(); setScale(scale + (e.deltaY < 0 ? 0.06 : -0.06)); } }, { passive: false });
    $('#zin').onclick = function () { setScale(scale + 0.1); };
    $('#zout').onclick = function () { setScale(scale - 0.1); };
    $('#zfit').onclick = function () { setScale(0.62); sc.scrollTo(0, 0); };
  }

  /* ================= characters tab ================= */
  var houseFilter = 'all';
  function buildChars() {
    var f = $('#filters');
    var all = el('button', 'chip on', 'All'); all.dataset.h = 'all'; f.appendChild(all);
    Object.keys(HOUSE).forEach(function (k) {
      var b = el('button', 'chip', '<i style="background:' + HOUSE[k][1] + '"></i>' + HOUSE[k][0]); b.dataset.h = k; f.appendChild(b);
    });
    f.onclick = function (e) {
      var b = e.target.closest('button'); if (!b) return;
      houseFilter = b.dataset.h;
      Array.prototype.forEach.call(f.children, function (x) { x.classList.toggle('on', x === b); });
      drawChars();
    };
    drawChars();
  }
  function drawChars() {
    var g = $('#cgrid'); g.innerHTML = '';
    D.chars.forEach(function (c) {
      if (houseFilter !== 'all' && c.h !== houseFilter) return;
      var d = el('div', 'ccard');
      d.style.setProperty('--hc', HOUSE[c.h][1]);
      d.innerHTML = '<img class="portrait" data-p="' + c.id + '" src="' + (IMG[c.id] || BLANK) + '" alt="' + esc(c.n) + '"><h3>' + esc(c.n) + '</h3><p>' + esc(c.r) + '</p>';
      d.onclick = function () { showChar(c.id); };
      g.appendChild(d);
    });
  }

  /* ================= other tabs ================= */
  function buildWeapons() {
    var b = $('#weaponBox');
    b.innerHTML = '<h2 class="sec">Divine weapons and astras</h2><p class="lead">Astras are weapons invoked by mantra. Each needs knowledge of how to call it and how to recall it. Arjuna, Drona and Ashwatthama are among the few who know the greatest of them.</p>';
    var cards = el('div', 'cards'); b.appendChild(cards);
    D.weapons.forEach(function (w) {
      var c = el('div', 'card wcard');
      c.id = 'w-' + w.id;
      c.innerHTML = '<img data-w="' + w.id + '" src="' + BLANK + '" alt="' + esc(w.n) + '"><div><h3>' + esc(w.n) + '</h3><p>' + esc(w.d) + '</p><small>' + esc(w.t) + ' &middot; ' + esc(w.o) + '</small></div>';
      cards.appendChild(c);
    });
  }

  function buildStory() {
    var b = $('#storyBox');
    b.innerHTML = '<h2 class="sec">The story in eighteen books</h2><p class="lead">' + esc(D.story.intro) + '</p>';
    D.story.parvas.forEach(function (p) {
      var d = el('details', '', '<summary><span class="no">' + p.n + '</span>' + esc(p.name) + '</summary><p>' + esc(p.s) + '</p>');
      d.id = 'p-' + p.n; b.appendChild(d);
    });
    b.appendChild(el('h2', 'sec', 'Subplots that drive the epic'));
    var cards = el('div', 'cards'); b.appendChild(cards);
    D.story.subplots.forEach(function (s) { cards.appendChild(el('div', 'card', '<h3>' + esc(s.t) + '</h3><p>' + esc(s.d) + '</p>')); });
  }

  function buildWar() {
    var w = D.warfare, b = $('#warBox'), h = '<h2 class="sec">The war at Kurukshetra</h2><div class="stats">';
    w.stats.forEach(function (s) { h += '<div class="stat"><b>' + esc(s.k) + '</b><span>' + esc(s.v) + '</span></div>'; });
    h += '</div><p class="lead">' + esc(w.akshauhini) + '</p>';
    h += '<h2 class="sec">Commanders</h2><div class="cards">';
    w.commanders.forEach(function (c) { h += '<div class="card"><h3>' + esc(c.who) + '</h3><p>' + esc(c.side) + ' commander</p><small>Days ' + esc(c.days) + '</small></div>'; });
    h += '</div><h2 class="sec">Day by day</h2><div class="tl">';
    w.days.forEach(function (d) { h += '<div><b>Day ' + esc(d.d) + '</b><em>' + esc(d.c) + '</em><br>' + esc(d.t) + '</div>'; });
    h += '</div><h2 class="sec">Battle formations (vyuhas)</h2><div class="cards">';
    w.formations.forEach(function (f) { h += '<div class="card"><h3>' + esc(f.n) + '</h3><p>' + esc(f.d) + '</p></div>'; });
    h += '</div><h2 class="sec">Classes of warrior</h2><div class="cards">';
    w.classes.forEach(function (f) { h += '<div class="card"><h3>' + esc(f.n) + '</h3><p>' + esc(f.d) + '</p></div>'; });
    h += '</div><h2 class="sec">Rules of war, and who broke them</h2><div class="cards"><div class="card"><h3>The agreed rules</h3><ul class="rules">';
    w.rules.forEach(function (r) { h += '<li>' + esc(r) + '</li>'; });
    h += '</ul></div>';
    w.violations.forEach(function (v) { h += '<div class="card"><h3>' + esc(v.w) + '</h3><p>' + esc(v.h) + '</p></div>'; });
    h += '</div>';
    b.innerHTML = h;
  }

  function buildWriter() {
    var w = D.writer, b = $('#writerBox'), h = '<h2 class="sec">A writer\'s toolkit</h2><p class="lead">What the epic does so well, and how to borrow it.</p>';
    function block(title, arr, k) {
      h += '<h2 class="sec">' + title + '</h2><div class="cards">';
      arr.forEach(function (x) { h += '<div class="card"><h3>' + esc(x[k]) + '</h3><p>' + esc(x.d) + '</p></div>'; });
      h += '</div>';
    }
    block('Themes', w.themes, 't');
    block('Storytelling devices', w.devices, 't');
    block('Character arcs', w.arcs, 'n');
    h += '<h2 class="sec">Writing prompts</h2><div class="cards">';
    w.prompts.forEach(function (p) { h += '<div class="card"><p>' + esc(p) + '</p></div>'; });
    h += '</div>';
    b.innerHTML = h;
  }

  /* ================= detail window with a live 3D figure ================= */
  var V = null;
  function openViewer(c) {
    if (!glOK) { $('#viewer').innerHTML = '<img src="' + (IMG[c.id] || BLANK) + '" width="300">'; return; }
    var box = $('#viewer'), w = Math.min(340, window.innerWidth - 60), h = Math.round(w * RH / RW);
    if (!V) {
      var r = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      var s = new THREE.Scene(); var rl = lights(s);
      V = { r: r, s: s, rl: rl, c: null, g: null, base: 0, drag: false, lx: 0, t: 0, raf: 0 };
      r.domElement.addEventListener('pointerdown', function (e) { V.drag = true; V.lx = e.clientX; r.domElement.setPointerCapture(e.pointerId); });
      r.domElement.addEventListener('pointermove', function (e) { if (V.drag) { V.base += (e.clientX - V.lx) * 0.012; V.lx = e.clientX; } });
      r.domElement.addEventListener('pointerup', function () { V.drag = false; });
    }
    V.r.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    V.r.setSize(w, h); V.c = makeCamera(w / h);
    if (V.g) { V.s.remove(V.g); dispose(V.g); }
    V.g = buildFigure(c); V.s.add(V.g); V.rl.color.set(HOUSE[c.h][1]); V.base = 0; V.t = 0;
    box.innerHTML = ''; box.appendChild(V.r.domElement);
    cancelAnimationFrame(V.raf);
    (function loop() {
      V.raf = requestAnimationFrame(loop);
      V.t += 0.016;
      V.g.rotation.y = V.base + (V.drag ? 0 : Math.sin(V.t * 0.9) * 0.45);
      V.g.children.forEach(function (ch) { if (ch.userData && ch.userData.spin) ch.rotation.z += 0.03; });
      V.r.render(V.s, V.c);
    })();
  }

  function chipList(ids) {
    return ids.map(function (i) {
      var c = byId[i]; if (!c) return '';
      return '<span class="chip" data-id="' + i + '"><i style="background:' + HOUSE[c.h][1] + '"></i>' + esc(c.n) + '</span>';
    }).join('');
  }

  function showChar(id) {
    var c = byId[id]; if (!c) return;
    $('#modal').classList.add('show'); $('#modal').setAttribute('aria-hidden', 'false');
    openViewer(c);
    var info = $('#info');
    info.innerHTML = '<h2>' + esc(c.n) + '</h2><div class="rl">' + esc(c.r) + ' &middot; ' + esc(HOUSE[c.h][0]) + '</div>' +
      '<h4>Who they are</h4><p>' + esc(c.b) + '</p><h4>Fate</h4><p>' + esc(c.f) + '</p><div id="fam"></div>';
    api('/api/characters/' + encodeURIComponent(id)).then(function (r) {
      var rel = r.relatives, h = '';
      if (rel.parents.length) h += '<h4>Parents</h4><div class="rels">' + chipList(rel.parents) + '</div>';
      if (rel.spouses.length) h += '<h4>Spouse</h4><div class="rels">' + chipList(rel.spouses) + '</div>';
      if (rel.children.length) h += '<h4>Children</h4><div class="rels">' + chipList(rel.children) + '</div>';
      if (rel.siblings.length) h += '<h4>Siblings</h4><div class="rels">' + chipList(rel.siblings) + '</div>';
      var fam = $('#fam'); if (fam) fam.innerHTML = h;
    }).catch(function () {});
  }
  function closeModal() {
    $('#modal').classList.remove('show'); $('#modal').setAttribute('aria-hidden', 'true');
    if (V) cancelAnimationFrame(V.raf);
  }

  /* ================= tabs, search ================= */
  function openTab(name) {
    Array.prototype.forEach.call(document.querySelectorAll('#tabs button'), function (b) { b.classList.toggle('on', b.dataset.tab === name); });
    Array.prototype.forEach.call(document.querySelectorAll('.tab'), function (t) { t.classList.toggle('on', t.id === 'tab-' + name); });
    window.scrollTo(0, 0);
  }
  function setupUI() {
    $('#tabs').onclick = function (e) { var b = e.target.closest('button'); if (b) openTab(b.dataset.tab); };
    $('#close').onclick = closeModal;
    $('#modal').onclick = function (e) {
      if (e.target.id === 'modal') closeModal();
      var ch = e.target.closest('.chip[data-id]'); if (ch) showChar(ch.dataset.id);
    };
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });

    var q = $('#q'), res = $('#results'), timer = 0;
    q.oninput = function () {
      clearTimeout(timer);
      timer = setTimeout(function () {
        if (q.value.trim().length < 2) { res.classList.remove('show'); return; }
        api('/api/search?q=' + encodeURIComponent(q.value)).then(function (list) {
          res.innerHTML = list.length ? '' : '<div>No results</div>';
          list.forEach(function (r) {
            var d = el('div', '', esc(r.name) + '<small>' + esc(r.type) + ' &middot; ' + esc(r.note) + '</small>');
            d.onclick = function () {
              res.classList.remove('show'); q.value = '';
              if (r.type === 'character') showChar(r.id);
              if (r.type === 'weapon') { openTab('weapons'); var w = document.getElementById('w-' + r.id); if (w) w.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
              if (r.type === 'parva') { openTab('story'); var p = document.getElementById('p-' + r.id); if (p) { p.open = true; p.scrollIntoView({ behavior: 'smooth', block: 'center' }); } }
            };
            res.appendChild(d);
          });
          res.classList.add('show');
        });
      }, 200);
    };
    document.addEventListener('click', function (e) { if (!e.target.closest('#searchbox')) res.classList.remove('show'); });
  }

  /* ================= render portraits one by one so the page stays smooth ================= */
  var IMG = {};
  function renderAll() {
    var jobs = [];
    D.chars.forEach(function (c) { jobs.push({ t: 'c', o: c }); });
    D.weapons.forEach(function (w) { jobs.push({ t: 'w', o: w }); });
    var i = 0, bar = $('#loadbar i');
    (function next() {
      if (i >= jobs.length) { bar.style.width = '100%'; setTimeout(function () { $('#loadbar').style.opacity = 0; }, 500); return; }
      var j = jobs[i++];
      try {
        var url, sel;
        if (j.t === 'c') { url = IMG[j.o.id] = portraitFor(j.o); sel = 'img[data-p="' + j.o.id + '"]'; }
        else { url = weaponImage(j.o); sel = 'img[data-w="' + j.o.id + '"]'; }
        Array.prototype.forEach.call(document.querySelectorAll(sel), function (im) { im.src = url; });
      } catch (e) { /* skip one broken figure */ }
      bar.style.width = Math.round(i / jobs.length * 100) + '%';
      setTimeout(next, 0);
    })();
  }

  /* ================= start ================= */
  Promise.all([api('/api/characters'), api('/api/weapons'), api('/api/story'), api('/api/warfare'), api('/api/writer')])
    .then(function (r) {
      D.chars = r[0]; D.weapons = r[1]; D.story = r[2]; D.warfare = r[3]; D.writer = r[4];
      D.chars.forEach(function (c) { byId[c.id] = c; });
      initRender();
      buildTree(); setupPan(); buildChars(); buildWeapons(); buildStory(); buildWar(); buildWriter(); setupUI();
      renderAll();
    })
    .catch(function (e) {
      document.body.insertAdjacentHTML('beforeend', '<p style="padding:40px;color:#ff9a9a">Could not load data from the backend. Start it with <b>node server.js</b> and open http://localhost:3000. (' + esc(e.message) + ')</p>');
    });
})();
